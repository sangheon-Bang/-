package model;
/**
 * 재고처리하는 모델
 * 들어갈 것들 순번.num 물건이름.name(불벅, 신라면, 오징어땅콩 같은..), 가격.price, 재고갯수.count
 */
public class Stock {

}
