package view;


/**
 * 제일 처음 실행되는 로그인.java
 * 다른 패널들이 로그인.java는 계속 돌아가며 서버를 콘솔상에서 운용할 것이다..
 */

public class A_Main {
	public static void main(String[] args) {		
		new Login_Fr();		
	}
}
